<?php

	require_once("../dbconfig.php");

	if($sku=='' || $name=='' || $price==''){

	extract($_POST);

	$sql = "UPDATE products SET sku='$sku', name='$name', price='$price' WHERE id='$id'";

	$db->query($sql);

	if($db->affected_rows>0){
		$msg = "Successfully Updated";
		header("Location: ../products.php?msg=$msg");
	}

}


?>