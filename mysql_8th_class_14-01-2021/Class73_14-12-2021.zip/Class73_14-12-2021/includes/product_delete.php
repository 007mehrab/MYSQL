<?php

	// echo "This is Delete Page";
	
	// echo $_GET['pid'];


	require_once('../dbconfig.php');
	$id = $_GET['pid'];

	$sql = "DELETE FROM products WHERE id = '$id'";
	$db->query($sql);

	header("Location: ../products.php");


?>