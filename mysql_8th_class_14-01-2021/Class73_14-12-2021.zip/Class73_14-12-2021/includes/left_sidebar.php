<div class="col-sm-2 sidenav">
      <p><a href="products.php">Products</a></p>
      <p><a href="#">Link</a></p>
      <p><a href="#">Link</a></p>
    </div>