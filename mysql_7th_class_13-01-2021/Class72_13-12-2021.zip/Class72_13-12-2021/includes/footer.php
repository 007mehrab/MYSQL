<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>